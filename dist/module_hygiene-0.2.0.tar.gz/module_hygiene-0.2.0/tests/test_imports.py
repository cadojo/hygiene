"""
Is this package import-able?
"""

def test_hygiene():
    import hygiene

    return True
