"""
Unit tests for module-hygiene.
"""
