# Changelog

## Version 0.1 (development)

- Initial release!

## Version 1.0 (stable)

- Docs included!

## Version 2.0

- Docs removed!
- Instead of calling `exec`, the `cleanup` function now inspects the parent stack frame! 🤠
