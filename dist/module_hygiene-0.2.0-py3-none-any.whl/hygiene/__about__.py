"""
All static metadata for module-hygiene!

Right now, this is exclusively used for version management with hatch/hatchlings, and is 
explicitly excluded from all build files.
"""

__version__ = '0.2.0'
